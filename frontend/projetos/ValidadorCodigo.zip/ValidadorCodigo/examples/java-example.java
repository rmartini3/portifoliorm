// Exemplo de classe e método em Java
public class Main {
    public static void main(String[] args) {
        // Imprime uma mensagem no console
        System.out.println("Olá, Mundo!");

        // Chamando um método
        int resultado = soma(5, 7);
        System.out.println("A soma é: " + resultado);
    }

    // Método para somar dois números
    public static int soma(int a, int b) {
        return a + b;
    }
}