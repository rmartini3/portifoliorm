# Exemplo de função em Python
def saudacao(nome):
    print(f"Olá, {nome}!")

# Chamando a função
saudacao("Mundo")

# Exemplo de laço de repetição com for
for i in range(3):
    print(f"Contagem: {i}")

# Exemplo de uma lista e acesso a um elemento
frutas = ["maçã", "banana", "cereja"]
print("Minha fruta favorita é:", frutas[1])

# Exemplo de condicional
idade = 20
if idade >= 18:
    print("Você é maior de idade.")
else:
    print("Você é menor de idade.")