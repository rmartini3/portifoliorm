const chatBox = document.getElementById('chatBox');

class ChatManager {
    adicionarMensagem(html, senderClass) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${senderClass}`;
        messageDiv.innerHTML = `<div class="message-header"><span>Assistente</span><span class="timestamp">${new Date().toLocaleTimeString()}</span></div><div class="message-content">${html}</div>`;
        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

export const chatManager = new ChatManager();