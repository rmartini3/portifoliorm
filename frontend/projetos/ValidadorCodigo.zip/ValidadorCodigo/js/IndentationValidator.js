export class IndentationValidator {
    validate(code, language) {
        switch(language) {
            case 'python': return this.validatePythonIndentation(code);
            default: return this.validateGeneralIndentation(code, language);
        }
    }

    validateGeneralIndentation(code, language) {
        const lines = code.split('\n');
        let spaces = 0;
        let tabs = 0;
        for (const line of lines) {
            if (line.startsWith(' ')) spaces++;
            if (line.startsWith('\t')) tabs++;
        }
        if (spaces > 0 && tabs > 0) {
            return '<p class="error">❌ Identação inconsistente: mistura de espaços e tabs.</p>';
        }
        return '<p class="success">✅ Identação consistente.</p>';
    }

    validatePythonIndentation(code) {
        const lines = code.split('\n');
        let indentLevel = 0;
        let previousIndent = 0;
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            const currentIndent = lines[i].search(/\S|$/);
            if (line.endsWith(':')) {
                indentLevel++;
            }
            if (currentIndent < previousIndent) {
                indentLevel--;
            }
            if (currentIndent !== indentLevel * 4) {
                return `<p class="error">❌ Problema de identação na linha ${i+1}. Python requer 4 espaços por nível.</p>`;
            }
        }
        return '<p class="success">✅ Indentação Python válida.</p>';
    }
}