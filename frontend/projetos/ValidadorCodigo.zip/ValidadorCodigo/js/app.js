import { LanguageDetector } from './LanguageDetector.js';
import { SyntaxValidator } from './SyntaxValidator.js';
import { IndentationValidator } from './IndentationValidator.js';
import { PooUmlValidator } from './PooUmlValidator.js';
import { chatManager } from './chat.js';
import { LanguageTips } from './LanguageTips.js';

document.addEventListener('DOMContentLoaded', () => {
    // Referências aos elementos do DOM
    const languageSelect = document.getElementById('languageSelect');
    const codeInput = document.getElementById('codeInput');
    const validateButton = document.getElementById('runButton');
    const checkIndentation = document.getElementById('checkIndentation');
    const checkOOP = document.getElementById('checkOOP');
    const clearButton = document.getElementById('clearButton');
    const chatBox = document.getElementById('chatBox');
    const currentLanguageSpan = document.getElementById('currentLanguage'); // NOVO: Captura do span da linguagem
    const tipOfTheDayP = document.getElementById('tipOfTheDay');             // NOVO: Captura do parágrafo da dica

    // Instanciação das classes de lógica
    const detector = new LanguageDetector();
    const syntaxValidator = new SyntaxValidator(detector);
    const indentationValidator = new IndentationValidator();
    const pooUmlValidator = new PooUmlValidator();
    const languageTips = new LanguageTips(); // NOVO: Instanciação da classe de dicas

    // Função principal de validação
    async function handleValidation() {
        // ... (código de validação permanece o mesmo) ...
        const selectedLanguage = languageSelect.value;
        const codeToValidate = codeInput.value;

        if (!codeToValidate.trim()) {
            chatManager.adicionarMensagem("Por favor, insira um trecho de código para validar.", 'assistant-message warning');
            return;
        }

        const userMessageHtml = `<pre class="code-example">${syntaxValidator.escapeHtml(codeToValidate)}</pre>`;
        chatManager.adicionarMensagem(userMessageHtml, 'user-message', 'Você');

        await syntaxValidator.validate(codeToValidate, selectedLanguage);

        if (checkIndentation.checked) {
            const indentationResult = indentationValidator.validate(codeToValidate, selectedLanguage);
            chatManager.adicionarMensagem(indentationResult, 'assistant-message');
        }

        if (checkOOP.checked) {
            const oopResult = pooUmlValidator.validate(codeToValidate, selectedLanguage);
            chatManager.adicionarMensagem(oopResult, 'assistant-message');
        }
    }

    // Função para limpar o chat
    function clearChat() {
        // ... (código de limpar o chat permanece o mesmo) ...
        chatBox.innerHTML = '';
        const welcomeMessage = `
            <div class="message assistant-message">
                <div class="message-header">
                    <span>Assistente</span>
                    <span class="timestamp">${new Date().toLocaleTimeString()}</span>
                </div>
                <p>Olá! Cole seu código e clique em "Validar Código" para verificar sua sintaxe, identação e princípios POO/UML.</p>
            </div>`;
        chatBox.innerHTML = welcomeMessage;
    }

    // NOVO: Função para atualizar a linguagem selecionada e a dica
    function updateLanguageInfo(language) {
        const tip = languageTips.getRandomTip(language);
        const languageName = languageSelect.options[languageSelect.selectedIndex].text;

        currentLanguageSpan.textContent = languageName;
        tipOfTheDayP.innerHTML = `💡 Dica: ${tip}`;
    }

    // "Ouvintes" de eventos
    validateButton.addEventListener('click', handleValidation);
    clearButton.addEventListener('click', clearChat);
    languageSelect.addEventListener('change', (event) => { // NOVO: "Ouvinte" para a troca de linguagem
        updateLanguageInfo(event.target.value);
    });

    // NOVO: Chamada inicial para exibir a primeira dica quando a página carrega
    updateLanguageInfo(languageSelect.value);
});