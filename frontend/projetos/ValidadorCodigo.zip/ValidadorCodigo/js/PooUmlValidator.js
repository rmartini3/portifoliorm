export class PooUmlValidator {
    validate(code, language) {
        switch(language) {
            case 'java': return this.validateJavaOOP(code);
            case 'python': return this.validatePythonOOP(code);
            case 'javascript': return this.validateJavaScriptOOP(code);
            default: return '';
        }
    }

    validateJavaOOP(code) {
        let hasClasses = code.includes('class ');
        let hasObjects = code.includes('new ');
        let hasInheritance = code.includes('extends ');
        let hasEncapsulation = (code.includes('private ') || code.includes('protected '));
        return this.generateOOPResult(hasClasses, hasObjects, hasInheritance, hasEncapsulation);
    }

    validatePythonOOP(code) {
        let hasClasses = code.includes('class ');
        let hasObjects = code.includes('(') && code.includes(')');
        let hasInheritance = code.includes('class ') && code.includes('(');
        let hasEncapsulation = code.includes('__') || code.includes('_');
        return this.generateOOPResult(hasClasses, hasObjects, hasInheritance, hasEncapsulation);
    }

    validateJavaScriptOOP(code) {
        let hasClasses = code.includes('class ') || code.includes('function ');
        let hasObjects = code.includes('{') && code.includes('}') && code.includes(':');
        let hasInheritance = code.includes('extends ');
        let hasEncapsulation = code.includes('this.');
        return this.generateOOPResult(hasClasses, hasObjects, hasInheritance, hasEncapsulation);
    }

    generateOOPResult(hasClasses, hasObjects, hasInheritance, hasEncapsulation) {
        if (hasClasses || hasObjects || hasInheritance || hasEncapsulation) {
            let oopDetails = '<div class="oop-valid">';
            oopDetails += '<p class="success">✅ Características POO detectadas:</p><ul>';
            if (hasClasses) oopDetails += '<li>Classes</li>';
            if (hasObjects) oopDetails += '<li>Objetos</li>';
            if (hasInheritance) oopDetails += '<li>Herança</li>';
            if (hasEncapsulation) oopDetails += '<li>Encapsulamento</li>';
            oopDetails += '</ul></div>';
            return oopDetails;
        } else {
            return '<div class="oop-invalid"><p class="warning">⚠️ Poucas ou nenhuma característica de POO/UML detectada.</p></div>';
        }
    }
}