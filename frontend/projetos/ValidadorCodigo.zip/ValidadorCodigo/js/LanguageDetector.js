export class LanguageDetector {
    detectLanguage(code) {
        const cleanCode = code.trim();
        if (cleanCode === '') return 'unknown';

        // Versão limpa, apenas com as linguagens do seu projeto
        if (this.isHTML(cleanCode)) return 'html';
        if (this.isJavaScript(cleanCode)) return 'javascript';
        if (this.isCSS(cleanCode)) return 'css';

        return 'unknown';
    }

    isHTML(code) {
        const htmlPatterns = [/^<!DOCTYPE html>/i, /<html[\s>]/i, /<body[\s>]/i, /<head[\s>]/i, /<title>/i, /<\/html>/i];
        const htmlScore = htmlPatterns.filter(pattern => pattern.test(code)).length;
        return htmlScore >= 2;
    }

 isCSS(code) {
    // Esta RegEx procura por um seletor válido (ex: .classe, #id, tag) 
    // antes de um bloco { ... }. As barras de escape nos colchetes foram removidas.
    const cssSelectorPattern = /^\s*([a-zA-Z0-9\s.#*-_>+~:[]="'"]+)\s*\{[^}]*\}/m;

    // Esta RegEx procura por regras como @media, @keyframes, etc.
    const atRulePattern = /@media|@keyframes|@import|@font-face/;

    // A detecção é positiva se encontrar um seletor ou uma regra '@'
    if (cssSelectorPattern.test(code) || atRulePattern.test(code)) {
        return !this.isHTML(code); // A única verificação externa necessária é para HTML
    }

    return false;
}

    isJavaScript(code) {
        const jsPatterns = [
            /=>/, 
            /\.addEventListener/, 
            /const\s+|let\s+|var\s+/, 
            /^function\s+\w+/, 
            /console\.log/, 
            /document\./, 
            /window\./, 
            /import\s+.*from/, 
            /export\s+/, 
            /new\s+\w+\(/, 
            /\(function\(\)\{/
        ];
        const jsScore = jsPatterns.filter(pattern => pattern.test(code)).length;
        return jsScore >= 1 && !this.isHTML(code);
    }

    // Funções isJava() e isPython() foram removidas.

    getLanguageName(langCode) {
        // Objeto de nomes limpo, sem Java e Python
        const names = {
            'html': 'HTML',
            'css': 'CSS',
            'javascript': 'JavaScript',
            'unknown': 'Desconhecida'
        };
        return names[langCode] || langCode;
    }
}