export class LanguageTips {
    constructor() {
        this.tips = {
            html: ["Use <!DOCTYPE html> no início do documento.", "Feche todas as tags corretamente.", "Use atributos 'alt' em imagens para acessibilidade."],
            css: ["Use unidades relativas (em, rem, %) para layouts responsivos.", "Mantenha a especificidade baixa para evitar o uso de '!important'.", "Use variáveis CSS para cores e valores repetitivos."],
            javascript: ["Use 'const' e 'let' em vez de 'var'.", "Sempre use comparação estrita (=== em vez de ==).", "Trate erros com try/catch."],
            java: ["Siga as convenções de nomenclatura (CamelCase).", "Use modificadores de acesso apropriados (public, private, etc.).", "Documente seu código com Javadoc."],
            python: ["Siga o PEP 8 para estilo de código.", "Use recuos de 4 espaços, não tabs.", "Use compreensões de lista para loops simples."],
        };

        this.examples = {
            html: {
                title: 'Exemplo de Código HTML',
                explanation: 'Um exemplo básico de página HTML.',
                code: `<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Exemplo HTML</title>
</head>
<body>
    <h1>Olá Mundo!</h1>
    <p>Este é um parágrafo de exemplo.</p>
</body>
</html>`
            },
            css: {
                title: 'Exemplo de Código CSS',
                explanation: 'Exemplo de estilização de elementos.',
                code: `body {
    background-color: #f0f0f0;
}
.container {
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 8px;
}`
            },
            javascript: {
                title: 'Exemplo de Código JavaScript',
                explanation: 'Uma função de saudação e um loop.',
                code: `function saudacao(nome) {
    console.log("Olá, " + nome + "!");
}
for (let i = 0; i < 3; i++) {
    saudacao("Usuário " + (i + 1));
}`
            },
            java: {
                title: 'Exemplo de Código Java',
                explanation: 'Uma classe Java com o método main.',
                code: `public class Main {
    public static void main(String[] args) {
        System.out.println("Olá do Java!");
    }
}`
            },
            python: {
                title: 'Exemplo de Código Python',
                explanation: 'Uma função e um loop em Python.',
                code: `def saudacao(nome):
    print(f"Olá, {nome}!")
for i in range(3):
    saudacao("Usuário")`
            }
        };
    }

    getExample(language) {
        return this.examples[language] || { title: 'Exemplo não encontrado', explanation: '', code: '' };
    }

    getRandomTip(language) {
        const selectedTips = this.tips[language] || this.tips['html'];
        const randomIndex = Math.floor(Math.random() * selectedTips.length);
        return selectedTips[randomIndex];
    }
}