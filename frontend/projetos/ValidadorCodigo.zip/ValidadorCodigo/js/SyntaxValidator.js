import { chatManager } from './chat.js';

export class SyntaxValidator {
    constructor(languageDetector) {
        this.languageDetector = languageDetector;
    }

    // A função principal agora é ASYNC para poder usar AWAIT
    async validate(code, selectedLanguage) {
        const detectedLanguage = this.languageDetector.detectLanguage(code);
        if (detectedLanguage !== 'unknown' && detectedLanguage !== selectedLanguage) {
            this.showLanguageMismatchError(detectedLanguage, selectedLanguage);
            return; // Interrompe
        }

        // Usa AWAIT para esperar a conclusão de cada validação
        switch (selectedLanguage) {
            case 'html':
                await this.validateHTML_W3C(code);
                break;
            case 'css':
                await this.validateCSS_W3C(code);
                break;
            case 'javascript':
                // A validação de JS é síncrona (rápida), não precisa de await aqui
                this.validateJavaScript(code);
                break;
        }
    }

    async validateHTML_W3C(code) {
        chatManager.adicionarMensagem('Analisando HTML com o validador W3C...', 'assistant-message info');
        try {
            const response = await fetch('https://validator.w3.org/nu/?out=json', {
                method: 'POST',
                headers: { 'Content-Type': 'text/html; charset=UTF-8' },
                body: code
            });
            const data = await response.json();
            const errors = data.messages.filter(msg => msg.type === 'error');

            if (errors.length === 0) {
                chatManager.adicionarMensagem('<p class="success">✅ Sintaxe HTML válida de acordo com o W3C.</p>', 'assistant-message');
            } else {
                let errorMessages = errors.map(err =>
                    `<div class="error-item">
                        <p class="error-title">❌ Erro na linha ${err.lastLine}:</p>
                        <p class="error-detail">${this.escapeHtml(err.message)}</p>
                        <pre class="code-example">${this.escapeHtml(err.extract)}</pre>
                    </div>`
                ).join('');
                chatManager.adicionarMensagem(errorMessages, 'assistant-message');
            }
        } catch (error) {
            chatManager.adicionarMensagem(`<p class="error">❌ Erro ao contatar o serviço de validação W3C: ${error.message}</p>`, 'assistant-message');
        }
    }

    async validateCSS_W3C(code) {
        chatManager.adicionarMensagem('Analisando CSS com o validador W3C Jigsaw...', 'assistant-message info');
        const formData = new FormData();
        formData.append("text", code);
        formData.append("output", "json");

        try {
            const response = await fetch('https://jigsaw.w3.org/css-validator/validator', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            const errors = data.cssvalidation.errors;

            if (!errors || errors.length === 0) {
                chatManager.adicionarMensagem('<p class="success">✅ Sintaxe CSS válida de acordo com o W3C.</p>', 'assistant-message');
            } else {
                let errorMessages = errors.map(err =>
                    `<div class="error-item">
                        <p class="error-title">❌ Erro na linha ${err.line}:</p>
                        <p class="error-detail">${this.escapeHtml(err.message)}</p>
                    </div>`
                ).join('');
                chatManager.adicionarMensagem(errorMessages, 'assistant-message');
            }
        } catch (error) {
            chatManager.adicionarMensagem(`<p class="error">❌ Erro ao contatar o serviço de validação W3C: ${error.message}</p>`, 'assistant-message');
        }
    }
    
    validateJavaScript(code) {
        try {
            new Function(code);
            chatManager.adicionarMensagem('<p class="success">✅ Sintaxe JavaScript válida.</p>', 'assistant-message');
        } catch (e) {
            const errorMessage = `<div class="error-item">
                                    <p class="error-title">❌ Erro de Sintaxe JavaScript:</p>
                                    <p class="error-detail">${this.escapeHtml(e.message)}</p>
                                  </div>`;
            chatManager.adicionarMensagem(errorMessage, 'assistant-message');
        }
    }

    showLanguageMismatchError(detectedLanguage, selectedLanguage) {
        const detectedName = this.languageDetector.getLanguageName(detectedLanguage);
        const selectedName = this.languageDetector.getLanguageName(selectedLanguage);
        const errorMessage = `
            <div class="error-container">
                <p class="error-title">⚠️ Possível linguagem incorreta detectada!</p>
                <p class="error-detail">Você selecionou <strong>${selectedName}</strong>, mas o código parece ser <strong>${detectedName}</strong>.</p>
                <p class="error-solution">A validação foi interrompida. Por favor, selecione a linguagem correta.</p>
            </div>
        `;
        chatManager.adicionarMensagem(errorMessage, 'assistant-message');
    }
    
    escapeHtml(unsafe) {
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }
}